# Kiểm chứng Power BI Customer 360

Kiểm thử trên Power BI Desktop 2.138.1452.0, ngày 14/10/2026. Dữ liệu phân tích là năm 2025, không phải dữ liệu ngày kiểm thử.

## Kết quả thực thi

- Import và refresh đầy đủ 12 bảng từ 8 CSV, 11 quan hệ một chiều, 51 measure.
- `Validate_KPIs.dax`: 40 phép đối chiếu với giá trị nguồn được kiểm chứng độc lập bằng Python và SQL Server; 40 đạt.
- `Validate_All_Measures.dax`: 51 measure được đánh giá trong engine Power BI ở ngữ cảnh tổng; 0 lỗi thực thi. Đây là kiểm tra thực thi, không phải chứng minh mọi ngữ cảnh lọc có kết quả đúng.
- Đã sửa tên biến DAX trùng tên hàm trong measure cohort, cập nhật mô hình trong Desktop và chạy lại đối chiếu.
- Đã mở và kiểm tra render cả 5 trang. Bộ lọc ngành hàng đã thử với Smartphone và đặt lại All trước khi lưu.
- Đã lưu bản dự án PBIP và xuất PBIX chứa dữ liệu.

| Chỉ tiêu | Kết quả |
|---|---:|
| Doanh thu đơn Completed | 53.357.307.150 ₫ |
| Đơn Completed / tất cả / hủy | 2.998 / 3.200 / 202 |
| Khách mua / hồ sơ | 575 / 600 |
| Khách có ít nhất 2 đơn | 516 |
| Doanh thu dòng hàng | 53.795.867.150 ₫ |
| Lợi nhuận gộp dòng hàng | 11.609.687.150 ₫ |
| Chênh lệch đối soát doanh thu | 0 ₫ |
| Yêu cầu dịch vụ hợp lệ / loại | 231 / 1 |
| Yêu cầu Open / khách có Open | 13 / 12 |
| Service recovery / retention / Champion / cross-sell | 12 / 48 / 81 / 92 |
| Cohort tháng 1: quy mô / M1 có mua | 154 / 61 |
| Cohort tháng 12, M1 | BLANK — chưa có kỳ quan sát |
| Marketplace: đơn / hủy | 293 / 52 |
| Doanh thu Q4 / Returning Q4 | 16.666.401.950 / 14.810.629.100 ₫ |

## Bộ lọc đã kiểm tra

Chọn Smartphone trong trang Bán hàng & hiệu quả: lợi nhuận dòng hàng 3,45 tỷ ₫, biên lợi nhuận 19,9%; tỷ lệ hủy đơn vẫn 6,3%, doanh thu / mục tiêu năm vẫn 74,7%. Bộ lọc ngành hàng chỉ tác động chỉ tiêu dòng sản phẩm; mô hình không tự phân bổ doanh thu cấp đơn theo sản phẩm.

## Bằng chứng và cách chạy lại

Ảnh Desktop trong `validation_proof/`: kiểm tra KPI, 51 measure, 5 trang và bộ lọc Smartphone. Mở DAX query view, tạo query, dán nội dung file kiểm tra và Run. Query kiểm tra đã được giữ trong dự án; file riêng có thêm hiển thị 0 khi tập lỗi rỗng, để tránh nhầm BLANK với lỗi.

8 CSV trong `Data/` được so sánh SHA-256 với thư mục dữ liệu người dùng, giữ nguyên nội dung. SR00032 được giữ trong dữ liệu nguồn và bị loại qua cờ Power Query khỏi KPI dịch vụ; không xóa dòng để che lỗi.

## Giới hạn của kết luận

Nguồn là dữ liệu giả lập và chỉ có lịch sử 2025. Phân khúc là quy tắc tại 31/12/2025, không phải mô hình dự báo churn. Trạng thái Open là snapshot nguồn vì không có resolved_at. Các chiến dịch là đề xuất pilot, chưa đo tác động. Chưa publish lên Power BI Service, cấu hình gateway hay scheduled refresh; bản giao là báo cáo Desktop.
