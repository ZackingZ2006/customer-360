# Customer 360 — Power BI

Mở Customer360.pbip để chỉnh sửa nguồn báo cáo. Customer360_Final.pbix là bản có dữ liệu nhúng được xuất từ dự án sau khi refresh và kiểm tra.

5 trang: Tổng quan; Khách hàng & hành động; Bán hàng & hiệu quả; Cohort & mua lại; Dịch vụ. Trong chế độ chỉnh sửa Desktop, Ctrl + bấm nút điều hướng; tab trang có thể bấm thường.

## Định nghĩa và kết quả chính

- 600 hồ sơ; 575 khách mua; 2.998 đơn hoàn tất; doanh thu 53.357.307.150 đồng.
- Retention M1 có trọng số: 232/554 = 41,88% (41,9% trên thẻ), chỉ tính cohort tháng 1–11. Khác với 516/575 = 89,7% khách mua từ hai đơn trong năm. Tháng 12 chưa quan sát M1 nên để trống.
- Ma trận có cột Số khách, tiếp theo M1–M11. Số khách không tham gia thang màu retention. Cohort tháng 11 có 29 khách, trong đó 22 khách quay lại (75,9%).
- Có 231 yêu cầu hợp lệ; 13 yêu cầu đang mở của 12 khách. CSAT toàn bộ yêu cầu: 4,03; đã xử lý (Resolved): 4,23; đang mở (Open): 1,77. Đây là ba phạm vi khác nhau.
- AsterSound Buds Lite: CSAT 3,95 (Resolved); 3,88 nếu tính mọi trạng thái. Bảng dịch vụ theo sản phẩm chỉ hiển thị sản phẩm bán từ 30 chiếc trở lên; 24 yêu cầu/123 sản phẩm = 19,5 yêu cầu/100 sản phẩm, không phải tỷ lệ lỗi.
- Hải Châu: thời gian xử lý 7,43 ngày trên 7 yêu cầu Resolved; trạng thái nguồn còn 2 yêu cầu Open.
- Champion: 109/600 = 18,2% khách, tạo 50,0% doanh thu. Hai tỷ trọng được đặt cùng biểu đồ để so sánh; tooltip có số khách và doanh thu.
- Chi nhánh sắp theo mức đạt mục tiêu giảm dần; dưới 60% tô đỏ. Biên lợi nhuận sắp theo chênh lệch tăng dần; giá trị âm tô đỏ. Smartphone và TV & Display là hai danh mục dưới mục tiêu.
- Biểu đồ doanh thu tháng bắt đầu từ 0, có đường trung bình năm 4,45 tỷ đồng; tháng 12 cao hơn trung bình 43,1%. Biểu đồ chi nhánh hiển thị đủ 12 chi nhánh. Số đơn theo kênh được đưa vào tooltip biểu đồ doanh thu kênh.

## Phạm vi bộ lọc

Phân khúc và hành động là ảnh chụp tại 31/12/2025, không đổi theo bộ lọc tháng. Cohort bỏ bộ lọc tháng để giữ nguyên nhóm mua đầu quan sát; vùng/kênh lọc hoạt động mua quay lại, không xác định lại cohort gốc. Thẻ M1 dùng cùng quy tắc và loại tháng chưa quan sát. Bảng dịch vụ áp ngưỡng 30 sản phẩm trong ngữ cảnh bộ lọc hiện tại. Đường trung bình doanh thu lấy 12 tháng năm 2025, giữ vùng/kênh, bỏ lọc tháng. Mục tiêu chi nhánh là cả năm, bỏ lọc tháng/kênh.

## Mô hình và tái lập

Giữ nguyên 8 CSV nguồn. DataFolder trỏ tới Data/ của bản này; chuyển máy cần sửa tham số trước khi Refresh. Mỗi khách chỉ nhận một hành động theo thứ tự: 12 xử lý dịch vụ → 48 giữ chân → 81 chăm sóc Champion → 92 bán chéo Audio → 367 chưa gán. Tiếp thị yêu cầu đồng ý nhận tin và không có yêu cầu đang mở.

Lợi nhuận gộp dòng hàng tính trước giảm giá cấp đơn, phí vận chuyển, hoàn tiền và chi phí vận hành. Dữ liệu giả lập chỉ có năm 2025; không kết luận mùa vụ hay hiệu quả chiến dịch. Loại SR00032 khỏi KPI dịch vụ do ngày yêu cầu trước ngày mua. resolution_days có giá trị cả với yêu cầu Open; thời gian xử lý chỉ dùng Resolved và cần xác minh định nghĩa. Thiếu resolved_at nên không tái dựng chính xác trạng thái lịch sử.

PBIP là mã nguồn báo cáo; PBIX là bản có dữ liệu nhúng. Khi chỉnh PBIP, cần xuất lại PBIX để đồng bộ. Truy vấn đối chiếu nằm trong `Validate_Review.dax` và `Validate_Review_Summary.dax`; kết quả được ghi trong `VALIDATION_REVIEW.json`.
